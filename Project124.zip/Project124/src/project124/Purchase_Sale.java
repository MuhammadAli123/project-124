/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project124;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import net.proteanit.sql.DbUtils;
import java.util.Date;
import java.text.MessageFormat;
import javax.swing.JTable;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import java.awt.Toolkit;
/**
 *
 * @author Ali
 */
public class Purchase_Sale extends javax.swing.JFrame {
    Connection connection = null;
    ResultSet rs = null;
    PreparedStatement pst = null;
   
    public Purchase_Sale() {
        initComponents();
        
       
     
    connection =   conn.DBconnect();
    Icon();
    Update_table();
    CurrentDate();
    
    }
    public void GETDATE(){
    try{
    String sql ="select Date from PurchaseSale";
     pst = connection.prepareStatement(sql);
      pst.execute();
    }   
     catch(Exception e){
       
     }
    }
    
       public void Icon(){
       
       JFrame frame = new JFrame();
       setTitle("Buissines Manager 1.0");
       setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("save.png")));
    
       }

        private void Update_table(){

        try{
    String sql ="select * from  PurchaseSale order by ID";
    pst = connection.prepareStatement(sql);
    rs = pst.executeQuery();
    SP_table.setModel(DbUtils.resultSetToTableModel(rs));
        
        }
    catch(Exception e){

     JOptionPane.showMessageDialog(null, e);
    }
        finally{
        try{
        rs.close();
        pst.close();
       }
        catch(Exception e){
        }
       }
        }
        
         public void closeLogin(){          // this Method will clos this window when new window is open
        
       WindowEvent winClosingEvent = new WindowEvent(this,WindowEvent.WINDOW_CLOSING);
       Toolkit.getDefaultToolkit().getSystemEventQueue().postEvent(winClosingEvent);
    
    }
         public void CurrentDate(){
         
           Thread clock = new Thread() {
           
             public void run(){
              
                  for(;;){
                 
                      try {
                          Calendar cal = new GregorianCalendar();
                          int month = cal.get(Calendar.MONTH);
                          int day   = cal.get(Calendar.DAY_OF_MONTH);
                          int year  = cal.get(Calendar.YEAR);
                          Date_txt.setText(" Date: "+day+"/"+(month+1)+"/"+year);
         
                          int sec  = cal.get(Calendar.SECOND);
                          int min  = cal.get(Calendar.MINUTE);
                          int hour = cal.get(Calendar.HOUR);
                          Time_txt.setText("  Time: "+hour+":"+min+":"+sec);
                          sleep(1000);
                      } catch (InterruptedException ex) {
                          Logger.getLogger(Purchase_Sale.class.getName()).log(Level.SEVERE, null, ex);
                      }
                 
                 }
              
             }
         
         };
            clock.start();
         }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        SP_table = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        Date = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        id_tf = new javax.swing.JTextField();
        MAname_tf = new javax.swing.JTextField();
        date_tf = new com.toedter.calendar.JDateChooser();
        purchase_tf = new javax.swing.JTextField();
        BRname_tf = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        sale_tf = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        reset_cmd = new javax.swing.JButton();
        save_cmd = new javax.swing.JButton();
        Delete_cmd = new javax.swing.JButton();
        update_cmd = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        TotalRessult = new javax.swing.JButton();
        TS_tf = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        TQ_tf = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        TP_tf = new javax.swing.JTextField();
        jPanel6 = new javax.swing.JPanel();
        search_tf = new javax.swing.JTextField();
        Report_cmd = new javax.swing.JButton();
        save_report = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        total = new javax.swing.JTextField();
        jToolBar1 = new javax.swing.JToolBar();
        Date_txt = new javax.swing.JLabel();
        Time_txt = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        Add_Sub = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        Add_btn = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        Sale_Add_Sub = new javax.swing.JTextField();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximizedBounds(new java.awt.Rectangle(0, 0, 0, 0));
        setMinimumSize(new java.awt.Dimension(1430, 880));
        setSize(new java.awt.Dimension(0, 0));

        jScrollPane1.setForeground(new java.awt.Color(0, 0, 255));

        SP_table.setForeground(new java.awt.Color(0, 51, 51));
        SP_table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        SP_table.setToolTipText("Table");
        SP_table.setRowHeight(30);
        SP_table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SP_tableMouseClicked(evt);
            }
        });
        SP_table.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                SP_tableKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                SP_tableKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(SP_table);

        jPanel1.setBackground(new java.awt.Color(204, 204, 255));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Purchase_Detail", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.BELOW_TOP, new java.awt.Font("Tahoma", 0, 12), new java.awt.Color(0, 0, 255))); // NOI18N

        Date.setText("Date");

        jLabel4.setText("Manufacture Name");

        date_tf.setDateFormatString(" yyyy-MM-dd");

        purchase_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                purchase_tfActionPerformed(evt);
            }
        });

        BRname_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BRname_tfActionPerformed(evt);
            }
        });

        jLabel5.setText("Purchase Quantity");

        jLabel1.setText("ID");

        jLabel3.setText("Brand Name");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(Date)
                            .addComponent(jLabel3))
                        .addGap(41, 41, 41)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(id_tf)
                            .addComponent(date_tf, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(BRname_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(purchase_tf))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(MAname_tf, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(id_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(Date))
                    .addComponent(date_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(BRname_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(MAname_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(purchase_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Sale_Detail", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.BELOW_TOP, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 0, 255))); // NOI18N

        sale_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sale_tfActionPerformed(evt);
            }
        });

        jLabel6.setText("Sale Quantity");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel6)
                .addGap(30, 30, 30)
                .addComponent(sale_tf)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(sale_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel3.setBackground(new java.awt.Color(204, 204, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Buttons", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.BELOW_TOP, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 0, 255))); // NOI18N

        reset_cmd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project124/res.PNG"))); // NOI18N
        reset_cmd.setText("Reset");
        reset_cmd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reset_cmdActionPerformed(evt);
            }
        });

        save_cmd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project124/save.png"))); // NOI18N
        save_cmd.setText("Save");
        save_cmd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_cmdActionPerformed(evt);
            }
        });

        Delete_cmd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project124/de.PNG"))); // NOI18N
        Delete_cmd.setText("Delete");
        Delete_cmd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Delete_cmdActionPerformed(evt);
            }
        });

        update_cmd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project124/up.PNG"))); // NOI18N
        update_cmd.setText("Update");
        update_cmd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_cmdActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(update_cmd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(save_cmd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(reset_cmd)
                    .addComponent(Delete_cmd))
                .addGap(28, 28, 28))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(save_cmd, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Delete_cmd, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(18, 18, Short.MAX_VALUE)
                        .addComponent(update_cmd)
                        .addContainerGap())
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(reset_cmd)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        jPanel5.setBackground(new java.awt.Color(204, 204, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Total Menu", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.BELOW_TOP, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 51, 255))); // NOI18N
        jPanel5.setToolTipText("All Total Quantities");

        jLabel10.setText("Total Purchase");

        TotalRessult.setText("Total Quantities");
        TotalRessult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TotalRessultActionPerformed(evt);
            }
        });

        TS_tf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TS_tfActionPerformed(evt);
            }
        });

        jLabel12.setText("Total Quantity");

        jLabel11.setText("Total Sale");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(TP_tf)
                            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(34, 34, 34)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(jLabel11)
                                .addGap(30, 30, 30))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addComponent(TS_tf)
                                .addGap(18, 18, 18)))
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(TQ_tf)))
                    .addComponent(TotalRessult, javax.swing.GroupLayout.Alignment.TRAILING))
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(TP_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TS_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TQ_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(TotalRessult)
                .addContainerGap())
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Search", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.BELOW_TOP, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 51, 255))); // NOI18N

        search_tf.setToolTipText("Search by id, BrandName,ManufactureName");
        search_tf.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                search_tfKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(search_tf, javax.swing.GroupLayout.DEFAULT_SIZE, 127, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(search_tf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        Report_cmd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project124/PRI.PNG"))); // NOI18N
        Report_cmd.setText("Print Report");
        Report_cmd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Report_cmdActionPerformed(evt);
            }
        });

        save_report.setIcon(new javax.swing.ImageIcon(getClass().getResource("/project124/SR.PNG"))); // NOI18N
        save_report.setText("Save Report");
        save_report.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_reportActionPerformed(evt);
            }
        });

        jPanel7.setBackground(new java.awt.Color(204, 204, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Total_Detail", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.BELOW_TOP, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(102, 102, 255))); // NOI18N

        jLabel13.setText("Total Quantity");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(total, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(total, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addContainerGap())
        );

        jToolBar1.setRollover(true);

        Date_txt.setText("Date");
        jToolBar1.add(Date_txt);

        Time_txt.setText("Time");
        jToolBar1.add(Time_txt);

        jPanel8.setBackground(new java.awt.Color(153, 153, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Purchase", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.BELOW_TOP));

        Add_Sub.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_SubActionPerformed(evt);
            }
        });

        jButton1.setText("Sub");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        Add_btn.setText("Add");
        Add_btn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Add_btnActionPerformed(evt);
            }
        });

        jLabel14.setText("Purcahse/PurchaseReturn");

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addGap(18, 18, 18)
                        .addComponent(Add_Sub, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Add_btn)))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(Add_Sub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(Add_btn))
                .addContainerGap())
        );

        jPanel4.setBackground(new java.awt.Color(153, 153, 255));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Sale return", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.BELOW_TOP));

        jButton2.setText("Sub");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel8.setText("Sale Return");

        jButton3.setText("Add");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(37, 37, 37)
                        .addComponent(Sale_Add_Sub, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(82, 82, 82)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jButton3)))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(Sale_Add_Sub, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addContainerGap())
        );

        jMenu1.setText("File");

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_N, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem1.setText("New");
        jMenu1.add(jMenuItem1);
        jMenu1.add(jSeparator1);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_C, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem2.setText("Close");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem2);

        jMenuBar1.add(jMenu1);

        jMenu2.setText("Edit");

        jMenuItem3.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_R, java.awt.event.InputEvent.CTRL_MASK));
        jMenuItem3.setText("Reset Fields");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu2.add(jMenuItem3);

        jMenuBar1.add(jMenu2);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(45, 45, 45))
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(281, 281, 281)
                                .addComponent(jLabel2))
                            .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 51, Short.MAX_VALUE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 603, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(save_report)
                                .addGap(27, 27, 27)
                                .addComponent(Report_cmd))
                            .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(75, 75, 75))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jToolBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(13, 13, 13)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(75, 75, 75)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(Report_cmd)
                                    .addComponent(save_report))
                                .addGap(18, 18, 18)
                                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(97, 97, 97)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(128, 128, 128)
                                        .addComponent(jLabel2)))
                                .addGap(169, 169, 169))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 339, javax.swing.GroupLayout.PREFERRED_SIZE))))))
        );

        setBounds(0, 0, 1025, 723);
    }// </editor-fold>//GEN-END:initComponents

    private void BRname_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BRname_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BRname_tfActionPerformed

    private void purchase_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_purchase_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_purchase_tfActionPerformed

    private void sale_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sale_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sale_tfActionPerformed

    private void save_cmdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_cmdActionPerformed
        
        try{
            
          String sql = "insert into PurchaseSale(ID, Date, BrandName, ManufactureName, PurchaseQuantiy, SaleQuantity, TotalQuantity ) values(?,?,?,?,?,?,?)";
          pst = connection.prepareStatement(sql);
      
       pst.setString(1, id_tf.getText());
       pst.setString(2,  ((JTextField)date_tf.getDateEditor().getUiComponent()).getText());
       pst.setString(3, BRname_tf.getText());
       pst.setString(4, MAname_tf.getText());
       pst.setString(5, purchase_tf.getText());
       pst.setString(6, sale_tf.getText());
       
        double sub = Double.parseDouble(purchase_tf.getText());
        double sub2 = Double.parseDouble(sale_tf.getText());
        double v = sub-sub2;
        total.setText(String.valueOf(v));
        pst.setString(7,total.getText());
            
           
   /*    String val  = purchase_tf.getText();
       String val2  = sale_tf.getText();
       String Total = val-val2;  */
   //    pst.setString(7, Total);
       if( sub >= sub2 ){
       JOptionPane.showMessageDialog(null, "saved");
       pst.execute();  
       }
        else{
            JOptionPane.showMessageDialog(null, "Purchase Quantity must be greater than Sale Quantity");
             }
        }
        catch(Exception e){
         JOptionPane.showMessageDialog(null, e);
        }
        try{
            Update_table();
        }
        
         finally{
              try{
                 rs.close();
                 pst.close();
                 }   
                 catch(Exception e){}
        }
        
        
        
    }//GEN-LAST:event_save_cmdActionPerformed

    private void Delete_cmdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Delete_cmdActionPerformed
        
        int p = JOptionPane.showConfirmDialog(null,"Do you Really want to Delete","Deleted",JOptionPane.YES_NO_OPTION );
        
       if(p == 0) { 
        try{
        String sql="Delete from PurchaseSale where ID=?";
        
        pst= connection.prepareStatement(sql);
        pst.setString(1, id_tf.getText());
        
        pst.execute();
        
        }
        catch(Exception e){
          JOptionPane.showMessageDialog(null, e);
        }
           }
        try {
            Update_table();
        }
         finally{
              try{
                 rs.close();
                 pst.close();
                 }   
                 catch(Exception e){}
                 }
    }//GEN-LAST:event_Delete_cmdActionPerformed

    private void SP_tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SP_tableMouseClicked
       
        try{
          int row = SP_table.getSelectedRow();
          String table_clicked = (SP_table.getModel().getValueAt(row, 0).toString());
          String sql = "select * from PurchaseSale where ID= '"+table_clicked+"' ";
          
          pst = connection.prepareStatement(sql);
          rs=pst.executeQuery();
          
          if(rs.next()){
          
               String add1 =rs.getString("ID");
              id_tf.setText(add1);
            /*  String add2 = rs.getDate("Date").toString();
              date_tf.setDateFormatString(add2);
            //  date_tf.setToolTipText(add2);     */
           /*   String add2 = rs.getString("Date");
          //    date_tf.setDateFormatString(add2);  */
               Date add2 = rs.getDate("Date");
              date_tf.setDate(add2);   
               String add3 =rs.getString("BrandName");
              BRname_tf.setText(add3);
               String add4 =rs.getString("ManufactureName");
              MAname_tf.setText(add4);
               String add5 =rs.getString("PurchaseQuantiy");
              purchase_tf.setText(add5);
               String add6 =rs.getString("SaleQuantity");
              sale_tf.setText(add6);
               String add7 =rs.getString("TotalQuantity");
              total.setText(add7);
          }
        
        }
         catch(Exception e){
           JOptionPane.showMessageDialog(null, e);
        Update_table();
        }
    }//GEN-LAST:event_SP_tableMouseClicked

    private void update_cmdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_cmdActionPerformed
        
        try{
         
            String val1 = id_tf.getText();
            String val2 =(((JTextField)date_tf.getDateEditor().getUiComponent()).getText()); 
        //    String Val7 = val2.CURRENT_DATE();
            String val3 = BRname_tf.getText();
            String val4 = MAname_tf.getText();
            String val5 = purchase_tf.getText();
            String val6 = sale_tf.getText();
            
            double sub = Double.parseDouble(purchase_tf.getText());
            double sub2 = Double.parseDouble(sale_tf.getText());
            double v = sub-sub2;
            total.setText(String.valueOf(v));
            String val7= total.getText();
            
            String sql = "update PurchaseSale set ID='"+val1+"' ,Date='"+val2+"', BrandName='"+val3+"' ,MAnufactureNAme='"+val4+"' ,PurchaseQuantiy='"+val5+"' ,SaleQuantity='"+val6+"',TotalQuantity='"+val7+"'  where ID='"+val1+"'";
            
            pst= connection.prepareStatement(sql);
           if(sub >= sub2){ 
            pst.execute();
            JOptionPane.showMessageDialog(null, "Updated");}
           else{
             JOptionPane.showMessageDialog(null, "Purchase Quantity must be greater than Sale Quantity");
           }
        }
        catch(Exception e){
          JOptionPane.showMessageDialog(null, e);
        }
        try{
          Update_table();
         }
        finally{
          try{
           pst.close();
           rs.close();
          }
          catch(Exception e){}
        }
    }//GEN-LAST:event_update_cmdActionPerformed

    private void reset_cmdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reset_cmdActionPerformed
        
        id_tf.setText("");
        date_tf.setDate(null);
        BRname_tf.setText("");
        MAname_tf.setText("");
        purchase_tf.setText("");
        sale_tf.setText("");
        total.setText("");
    }//GEN-LAST:event_reset_cmdActionPerformed
    
    private void TS_tfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TS_tfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TS_tfActionPerformed

    private void TotalRessultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TotalRessultActionPerformed
       
        try{
            String sql = "select sum(PurchaseQuantiy), sum(SaleQuantity), sum(TotalQuantity) from PurchaseSale";
            pst = connection.prepareStatement(sql);
            rs = pst.executeQuery();
            
            if(rs.next()){
              
                String sum1 = rs.getString("sum(PurchaseQuantiy)");
                TP_tf.setText(sum1);
               
                String sum2= rs.getString("sum(SaleQuantity)");
                TS_tf.setText(sum2);
                
                String sum3 = rs.getString("sum(TotalQuantity)");
                TQ_tf.setText(sum3);
            }
          }
        catch(Exception e){
          JOptionPane.showMessageDialog(null, e);
        }
        Update_table();
    }//GEN-LAST:event_TotalRessultActionPerformed

    private void search_tfKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_search_tfKeyReleased

        try{
            String sql = "Select * from PurchaseSale where ID=?";

            pst = connection.prepareStatement(sql);
            pst.setString(1, search_tf.getText());
            rs= pst.executeQuery();

            if(rs.next()){

                String add1 = rs.getString("ID");
                id_tf.setText(add1);
                Date add2 = rs.getDate("Date");
                date_tf.setDate(add2);
                String add3 = rs.getString("BrandName");
                BRname_tf.setText(add3);
                String add4 = rs.getString("ManufactureNAme");
                MAname_tf.setText(add4);
                String add5 = rs.getString("PurchaseQuantiy");
                purchase_tf.setText(add5);
                String add6 = rs.getString("SaleQuantity");
                sale_tf.setText(add6);
                String add7 = rs.getString("TotalQuantity");
                total.setText(add7);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
             
        // For BrandName
        try{

            String sql = "Select * from PurchaseSale where BrandName=?";

            pst = connection.prepareStatement(sql);
            pst.setString(1, search_tf.getText().toUpperCase().toLowerCase());
            rs = pst.executeQuery();

            if(rs.next()){

                String add1 = rs.getString("Id");
                id_tf.setText(add1);
                Date add2 = rs.getDate("Date");
                date_tf.setDate(add2);
                String add3 = rs.getString("BrandName");
                BRname_tf.setText(add3);
                String add4 = rs.getString("ManufactureNAme");
                MAname_tf.setText(add4);
                String add5 = rs.getString("PurchaseQuantiy");
                purchase_tf.setText(add5);
                String add6 = rs.getString("saleQuantity");
                sale_tf.setText(add6);
                String add7 = rs.getString("TotalQuantity");
                total.setText(add7);

            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
     
        try{

            String sql = "Select * from PurchaseSale where ManufactureNAme=? ";

            pst = connection.prepareStatement(sql);
            pst.setString(1, search_tf.getText().toUpperCase().toLowerCase());
            rs = pst.executeQuery();

            if(rs.next()){

                String add1 = rs.getString("ID");
                id_tf.setText(add1);
                Date add2 = rs.getDate("Date");
                date_tf.setDate(add2);
                String add3 = rs.getString("BrandName");
                BRname_tf.setText(add3);
                String add4 = rs.getString("ManufactureNAme");
                MAname_tf.setText(add4);
                String add5 = rs.getString("PurchaseQuantiy");
                purchase_tf.setText(add5);
                String add6 = rs.getString("SaleQuantity");
                sale_tf.setText(add6);
                String add7 = rs.getString("TotalQuantity");
                total.setText(add7);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
         finally{
          try{
           pst.close();
           rs.close();
          }
          catch(Exception e){}
        }
           Update_table();
    }//GEN-LAST:event_search_tfKeyReleased

    private void Report_cmdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Report_cmdActionPerformed
        
        MessageFormat header = new MessageFormat("Print Report");
        MessageFormat footer = new MessageFormat("Page{0,number,integer}");
        
        try{
          SP_table.print(JTable.PrintMode.NORMAL, header, footer);
        }
        catch(java.awt.print.PrinterException e){
            System.err.format("Cannot print %s%n", e.getMessage());
        }
    }//GEN-LAST:event_Report_cmdActionPerformed

    private void save_reportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_reportActionPerformed
       
        try{
      
     
            
        Document document = new Document();
        PdfWriter.getInstance(document,new FileOutputStream("Purchase_Sale.pdf"));
        document.open();
        Image image =  Image.getInstance("save.png");
        document.add(new Paragraph("image"));
        document.add(image);
        document.add(new Paragraph("ECHO TRADERS",FontFactory.getFont(FontFactory.TIMES_ROMAN,18,Font.BOLD,BaseColor.RED)));
        document.add(new Paragraph(new Date().toString())) ;
        document.add(new Paragraph("--------------------------------------------------------"));
        PdfPTable table = new PdfPTable(7);
        PdfPCell cell= new PdfPCell (new Paragraph("Purcahse_Sale Report"));
        
        cell.setColspan(7);
        
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setBackgroundColor(BaseColor.GREEN);
        
        table.addCell(cell);
        String sql = "select * from PurchaseSale";
             pst = connection.prepareStatement(sql);
          rs=pst.executeQuery();
      while(rs.next()){
                       
                        String v1 = rs.getString("ID");
                        String add = rs.getString("Date");          
                        String v2 = rs.getString("BrandName");
                        String v3 = rs.getString("ManufactureName");
                        String v4 = rs.getString("PurchaseQuantiy");
                        String v5 =rs.getString("SaleQuantity");
                        String v6 =rs.getString("TotalQuantity");

                  //  table.addCell("ID");
                    table.addCell(v1);
           //        table.addCell(v/*.date_tf.getDateFormatString()*/);
                    table.addCell(add);
                   //  table.addCell("Brand name");
                    table.addCell(v2);
                  //  table.addCell("Manyfacture Name");
                    table.addCell(v3);
                  //   table.addCell("purchase Quantity");
                    table.addCell(v4);
                    table.addCell(v5);
                    table.addCell(v6);
                       
         }
      document.add(table);
    /*   table.addCell("ID");
      //  String add1 =rs.getString("ID");
        table.addCell(val1);
        table.addCell("Date");
   //     Date d = rs.getDate("Date");
        table.addCell(val2);    //val2.date_tf.getDateFormatString()
        table.addCell("Brand Name");
      //  String add3 =rs.getString("BrandName");
        table.addCell(val3);
        table.addCell("Manufacture Name");
      //  String add4 = rs.getString("ManufactureName");
        table.addCell(val4); 
       table.addCell("Purchase Quantity");
     //   String add5 = rs.getString("PurchaseQuantiy");
        table.addCell(val5);
        table.addCell("Sale Quantity");
    //    String add6 = rs.getString("SaleQuantity");
        table.addCell(val6);
        table.addCell("Total Quantity");
      //  String add7 = rs.getString("TotalQuantity");
        table.addCell(val7);        */    //all close
      //  document.add(table);
        
        // List items
        com.itextpdf.text.List list = new com.itextpdf.text.List(true,20);
        list.add("Printed Date:_____________");
        list.add("Signature:_______________");
        document.add(list);
        
        document.close();
        JOptionPane.showMessageDialog(null, "Saved Report");
        }
        catch(Exception e){
           JOptionPane.showMessageDialog(null, e);
        }
    }//GEN-LAST:event_save_reportActionPerformed

    private void SP_tableKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SP_tableKeyPressed
        
   
    }//GEN-LAST:event_SP_tableKeyPressed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        closeLogin();
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
        
        id_tf.setText("");
        date_tf.setDate(null);
        BRname_tf.setText("");
        MAname_tf.setText("");
        purchase_tf.setText("");
        sale_tf.setText("");
        total.setText("");
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void Add_btnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_btnActionPerformed
        
        Double add1 = Double.parseDouble(purchase_tf.getText());
        Double add2 = Double.parseDouble( Add_Sub.getText());
        
        Double output = add1 + add2;
        
        purchase_tf.setText(String.valueOf(output));
        
    }//GEN-LAST:event_Add_btnActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        Double sub1 =  Double.parseDouble(purchase_tf.getText());
        Double sub2 =  Double.parseDouble(Add_Sub.getText());
        
        Double output= sub1 - sub2; 
        purchase_tf.setText(String.valueOf(output));
    }//GEN-LAST:event_jButton1ActionPerformed

    private void Add_SubActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Add_SubActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_Add_SubActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       
       // Sale addittion
        
         Double addSale  = Double.parseDouble(sale_tf.getText());
         Double addSale2 = Double.parseDouble(Sale_Add_Sub.getText()); 
         
         Double SaleAddOutput = addSale + addSale2;
         
         sale_tf.setText(String.valueOf(SaleAddOutput));
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        
        // Sale Subtraction add in Purchase field
       // sub btn sa value purchase ma plus ho jay
        Double SubSale  = Double.parseDouble(sale_tf.getText());
        Double SubSale2 = Double.parseDouble(Sale_Add_Sub.getText());
        
        Double SaleSubOutput = SubSale - SubSale2;
        
        sale_tf.setText(String.valueOf(SaleSubOutput));
        
        
        // for adding in Purchase_tf textfield 
        
        Double SaleTextField   = Double.parseDouble(purchase_tf.getText());
        Double SaleTextField2  = Double.parseDouble(Sale_Add_Sub.getText());
        
        Double SalTextFieldAdd = SaleTextField + SaleTextField2;
        
        purchase_tf.setText(String.valueOf(SalTextFieldAdd));
    }//GEN-LAST:event_jButton2ActionPerformed

    private void SP_tableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_SP_tableKeyReleased
       
             if(evt.getKeyCode()==KeyEvent.VK_DOWN || evt.getKeyCode()==KeyEvent.VK_UP){
            
                 try{
          int row = SP_table.getSelectedRow();
          String table_clicked = (SP_table.getModel().getValueAt(row, 0).toString());
          String sql = "select * from PurchaseSale where ID= '"+table_clicked+"' ";
          
          pst = connection.prepareStatement(sql);
          rs=pst.executeQuery();
          
          if(rs.next()){
          
               String add1 =rs.getString("ID");
              id_tf.setText(add1);
               Date add2 = rs.getDate("Date");
              date_tf.setDate(add2);   
               String add3 =rs.getString("BrandName");
              BRname_tf.setText(add3);
               String add4 =rs.getString("ManufactureName");
              MAname_tf.setText(add4);
               String add5 =rs.getString("PurchaseQuantiy");
              purchase_tf.setText(add5);
               String add6 =rs.getString("SaleQuantity");
              sale_tf.setText(add6);
               String add7 =rs.getString("TotalQuantity");
              total.setText(add7);
          }
        
        }
         catch(Exception e){
           JOptionPane.showMessageDialog(null, e);
        
        }
                    }
    }//GEN-LAST:event_SP_tableKeyReleased
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Purchase_Sale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Purchase_Sale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Purchase_Sale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Purchase_Sale.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Purchase_Sale().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Add_Sub;
    private javax.swing.JButton Add_btn;
    private javax.swing.JTextField BRname_tf;
    private javax.swing.JLabel Date;
    private javax.swing.JLabel Date_txt;
    private javax.swing.JButton Delete_cmd;
    private javax.swing.JTextField MAname_tf;
    private javax.swing.JButton Report_cmd;
    private javax.swing.JTable SP_table;
    private javax.swing.JTextField Sale_Add_Sub;
    private javax.swing.JTextField TP_tf;
    private javax.swing.JTextField TQ_tf;
    private javax.swing.JTextField TS_tf;
    private javax.swing.JLabel Time_txt;
    private javax.swing.JButton TotalRessult;
    private com.toedter.calendar.JDateChooser date_tf;
    private javax.swing.JTextField id_tf;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JTextField purchase_tf;
    private javax.swing.JButton reset_cmd;
    private javax.swing.JTextField sale_tf;
    private javax.swing.JButton save_cmd;
    private javax.swing.JButton save_report;
    private javax.swing.JTextField search_tf;
    private javax.swing.JTextField total;
    private javax.swing.JButton update_cmd;
    // End of variables declaration//GEN-END:variables

   
}



