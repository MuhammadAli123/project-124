package project124;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
public class conn {
    
    private Connection connection = null;
    
    public static Connection DBconnect(){
    
      try{
      Class.forName("org.sqlite.JDBC");
     Connection connection = DriverManager.getConnection("jdbc:sqlite:C:\\Users\\Ali\\Documents\\NetBeansProjects\\Project124\\Password.sqlite");
      return connection;
      }
     catch(Exception e){
         JOptionPane.showMessageDialog(null,e);
        return null;
     }
      }
    }
